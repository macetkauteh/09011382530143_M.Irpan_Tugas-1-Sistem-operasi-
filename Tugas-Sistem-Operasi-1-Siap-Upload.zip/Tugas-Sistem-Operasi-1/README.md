# LAPORAN TUGAS 1
## SISTEM OPERASI

### Identitas Mahasiswa
- **Nama:** M. Irpan
- **NIM:** 09011382530143
- **Mata Kuliah:** Sistem Operasi

---

## 1. Laporan Proses Instalasi

Laporan ini mendokumentasikan proses instalasi VirtualBox, Ubuntu 24.04.4, pengaturan mesin virtual, serta proses masuk ke Ubuntu.

### 1.1 Instalasi VirtualBox

Melakukan instalasi aplikasi VirtualBox sebagai perangkat lunak untuk menjalankan sistem operasi virtual.

### 1.2 Instalasi Ubuntu 24.04.4

Melakukan instalasi sistem operasi Ubuntu versi 24.04.4 ke dalam VirtualBox.

### 1.3 Pengaturan VirtualBox untuk Ubuntu

Melakukan pengaturan mesin virtual VirtualBox untuk menjalankan Ubuntu.

### 1.4 Proses Masuk ke Ubuntu

Proses ini mencakup fase awal, pembuatan akun, dan login ke sistem Ubuntu.

## 2. Analisis Mount Point `/`

**Pertanyaan:** Kenapa saat instalasi perlu dipilih `/` pada opsi Mount Point?

**Jawaban:**

Mount Point `/` disebut root directory (root filesystem) dan merupakan direktori utama dalam sistem Linux. Semua file dan direktori penting sistem Ubuntu berada di bawah `/`, seperti `/home`, `/etc`, `/var`, `/usr`, dan lainnya.

Oleh karena itu, ketika membuat partisi untuk instalasi Ubuntu, partisi utama harus diberikan Mount Point `/` agar Ubuntu mengetahui bahwa partisi tersebut digunakan sebagai filesystem utama untuk menjalankan sistem operasi.

Jika tidak ada partisi yang dipasang sebagai `/`, installer tidak memiliki lokasi utama untuk memasang sistem Ubuntu sehingga proses instalasi tidak dapat dilakukan dengan benar.

## 3. Penjelasan Jenis Filesystem

### 3.1 ext4

Filesystem Linux yang paling umum digunakan. Stabil, cepat, mendukung ukuran file dan partisi besar, serta memiliki fitur journaling.

### 3.2 ext3

Filesystem Linux generasi sebelumnya yang merupakan pengembangan dari ext2 dengan fitur journaling. Saat ini banyak digantikan oleh ext4.

### 3.3 swap

Area yang digunakan Linux sebagai memori virtual ketika RAM tidak mencukupi. Swap juga dapat digunakan untuk mendukung fitur hibernasi.

### 3.4 NTFS

Filesystem utama yang digunakan oleh Windows. Mendukung file dan partisi berukuran besar serta memiliki fitur keamanan dan journaling.

### 3.5 FAT32

Filesystem yang sangat kompatibel dengan berbagai sistem operasi dan perangkat. Kekurangannya, ukuran satu file maksimal sekitar 4 GB.

### 3.6 Btrfs

Filesystem Linux modern yang memiliki fitur seperti snapshot, compression, checksumming, dan pengelolaan volume yang lebih fleksibel.

## 4. Dokumentasi Screenshot

Screenshot berikut diekstrak dari dokumen tugas Word yang diberikan.

### Dokumentasi 1

![Dokumentasi 1](images/gambar-01.jpeg)

### Dokumentasi 2

![Dokumentasi 2](images/gambar-02.jpeg)

### Dokumentasi 3

![Dokumentasi 3](images/gambar-03.jpeg)

### Dokumentasi 4

![Dokumentasi 4](images/gambar-04.jpeg)

### Dokumentasi 5

![Dokumentasi 5](images/gambar-05.jpeg)

### Dokumentasi 6

![Dokumentasi 6](images/gambar-06.jpeg)

### Dokumentasi 7

![Dokumentasi 7](images/gambar-07.jpeg)

### Dokumentasi 8

![Dokumentasi 8](images/gambar-08.jpeg)

### Dokumentasi 9

![Dokumentasi 9](images/gambar-09.jpeg)

### Dokumentasi 10

![Dokumentasi 10](images/gambar-10.jpeg)

### Dokumentasi 11

![Dokumentasi 11](images/gambar-11.jpeg)

### Dokumentasi 12

![Dokumentasi 12](images/gambar-12.jpeg)

### Dokumentasi 13

![Dokumentasi 13](images/gambar-13.jpeg)

### Dokumentasi 14

![Dokumentasi 14](images/gambar-14.jpeg)

### Dokumentasi 15

![Dokumentasi 15](images/gambar-15.jpeg)

### Dokumentasi 16

![Dokumentasi 16](images/gambar-16.jpeg)

### Dokumentasi 17

![Dokumentasi 17](images/gambar-17.jpeg)

### Dokumentasi 18

![Dokumentasi 18](images/gambar-18.jpeg)

### Dokumentasi 19

![Dokumentasi 19](images/gambar-19.jpeg)

### Dokumentasi 20

![Dokumentasi 20](images/gambar-20.jpeg)

### Dokumentasi 21

![Dokumentasi 21](images/gambar-21.jpeg)

---

## Kesimpulan

Berdasarkan praktikum ini, mahasiswa telah mempelajari proses instalasi VirtualBox, instalasi Ubuntu 24.04.4, pengaturan mesin virtual, serta memahami Mount Point dan berbagai jenis filesystem pada sistem operasi.
